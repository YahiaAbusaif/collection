import numpy as np
import glob
import skimage.io as io
import cv2
import os
import sys
from time import time
from pipeline import run

def main(path=os.getcwd() + '/inDataSet/text/'):
    if not os.path.isdir("output"):
        os.mkdir("output")
        os.mkdir("output/text")
    samplesDIR = path
    noSamples = 100
    gen = glob.iglob(samplesDIR + "*.png")
    for i in range(noSamples):
        py = next(gen)
        input_image = io.imread(py)
        startTimer = time()
        allChars = run(input_image)

        endTimer = time()
        f = open("output/running_time.txt", "w")
        f.write(str(endTimer - startTimer))



if __name__ == "__main__":
    ## 1) read input data set
    
    ## 2) preprocess the sample 
    #       a- [noise] || convert to gray,
    #       b- binarization, 
    #       c- segment to lines, 
    #       d- segment to words, 
    #       e- check if count of words in text == count of segmented words)

    ## 3) feature extraction

    ## 4) post processing
    if len(sys.argv) < 2:
        print("Usage: python main.py [image_path].")
        main()
        #exit(0)
    else:
        main(sys.argv[1])