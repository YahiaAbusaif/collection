import cv2
import numpy as np
from scipy import stats
from imutils import contours as con
import os
import matplotlib.pyplot as plt

def show_images(images,titles=None):
    #This function is used to show image(s) with titles by sending an array of images and an array of associated titles.
    # images[0] will be drawn with the title titles[0] if exists
    # You aren't required to understand this function, use it as-is.
    n_ims = len(images)
    if titles is None: titles = ['(%d)' % i for i in range(1,n_ims + 1)]
    fig = plt.figure()
    n = 1
    for image,title in zip(images,titles):
        a = fig.add_subplot(1,n_ims,n)
        if image.ndim == 2: 
            plt.gray()
        plt.imshow(image)
        a.set_title(title)
        plt.axis('off')
        n += 1
    fig.set_size_inches(np.array(fig.get_size_inches()) * n_ims)
    plt.show() 

def ToGray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def horizontalProjection(img):
    return (np.sum(np.asarray(img), 1))//255

def verticalProjection(img):
    return (np.sum(np.asarray(img), 0))//255

#### Algorithm 4
def BaselineDetection(line):
    ## Binarization
    _, thresh = cv2.threshold(line,127,255,cv2.THRESH_BINARY_INV)
    HP = []
    HP = horizontalProjection(thresh)
    BaseLineIndex = 0
    MAX = 0
    for i in range(len(HP)):
        if HP[i-1] > HP[i] < HP[(i+1)%len(HP)]:
            if HP[i] > MAX:
                MAX = HP[i]
                BaseLineIndex = i   
    return BaseLineIndex

#### Algorithm 5
def FindingMaximumTransitions(line, BaselineIndex):
    _, line = cv2.threshold(line,127,255,cv2.THRESH_BINARY_INV)
    line //= 255
    MaxTransitions = 0
    MTI = BaselineIndex
    for i in range(BaselineIndex, 0, -1):
        CurrentTransitions = 0
        FLAG = 0
        for j in range(line.shape[1]):
            if line[i, j] == 1 and FLAG == 0:
                CurrentTransitions += 1
                FLAG = 1
            elif line[i, j] != 1 and FLAG == 1:
                FLAG = 0
        if CurrentTransitions >= MaxTransitions:
            MaxTransitions = CurrentTransitions
            MTI = i
    return MTI

def calCond(VP, val, start, end, mid):
    lis = []
    for i in range(start, end):
        if not val:
            if VP[i] == val:
                lis.append((i, abs(i-mid)))
        else:
            if VP[i] <= val:
                lis.append((i, abs(i-mid)))
    mn = 100000
    mnIdx = -1
    for idx, num in lis:
        if mn > num:
            mn = num
            mnIdx = idx
    return mnIdx

#### Algorithm 6
def CutPointIdentification(line, word, MTI):
    FLAG = 0
    i = 0
    VP = verticalProjection(line)
    MFV = stats.mode(VP)[0][0]
    StartIndex = 0
    EndIndex = 0
    MidIndex = 0
    CutIndex = 0
    SRL = []

    for i in range(word.shape[1]):
        if word[MTI, i] == 255 and FLAG == 0:
            EndIndex = i
            FLAG = 1
        elif word[MTI, i] != 255 and FLAG == 1:
            StartIndex = i
            MidIndex = (EndIndex + StartIndex) // 2
            c1 = calCond(VP, 0, StartIndex, EndIndex, MidIndex)
            c2 = calCond(VP, MFV, MidIndex, EndIndex, MidIndex)
            c3 = calCond(VP, MFV, StartIndex, MidIndex, MidIndex)
            if c1 != -1:
                CutIndex = c1
            elif VP[MidIndex] == MFV:
                CutIndex = MidIndex
            elif c2 != -1:
                CutIndex = c2
            elif c3 != -1:
                CutIndex = c3
            else:
                CutIndex = MidIndex
            SRL.append({"s": StartIndex, "e": EndIndex, "m": MidIndex, "c": CutIndex})
            FLAG = 0
    return SRL, MFV

#### Algorithm 7
def SeparationRegionFiltration(line, word, SRL, BaselineIndex, MTI, MFV):
    VP = verticalProjection(line)
    VSRL = []
    for i in range(len(SRL)):
        SR = SRL[i]
        if not VP[SR['c']]:
            VSRL.append(SR)
    pass


def LineSegmentation(img):
    # Binarization OTSU's
    _, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)
    # cv2.imwrite("threshold127.png", thresh)
    # _, thresh = cv2.threshold(img, 0, 255, cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)
    # cv2.imwrite("threshold0.png", thresh)
    rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 5))
    dilation = cv2.dilate(thresh, rect_kernel)
    # cv2.imwrite("dilation.png", dilation)

    _, contours0, _ = cv2.findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    lines = []
    #### sorting the contours from top to bottom
    contours, _ = con.sort_contours(contours0, method= "top-to-bottom")
    for _, contour in enumerate(contours, 1):
        x, y, w, h = cv2.boundingRect(contour)
        line = img[y:y+h, x:x+w]
        lines.append(line)
        ### saving the line as image
        # cv2.imwrite("line %i.png" %cnt, line)
    return lines

def WordSegmentation(line):
    #### Binarization OTSU's
    _,thresh = cv2.threshold(line, 127, 255,cv2.THRESH_OTSU | cv2.THRESH_BINARY_INV)
    rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    dilation = cv2.dilate(thresh, rect_kernel)
    _, contours0, _ = cv2.findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    
    words = []
    #### sorting the contours from right to left
    contours, _ = con.sort_contours(contours0, method="right-to-left")
    for _, contour in enumerate(contours, 1):
        x, y, w, h = cv2.boundingRect(contour)
        word = line[y:y+h,x:x+w]
        words.append(word)
        #### saving the word as image
        # cv2.imwrite("word %i.png"%cnt, word)
    return words


def isOverSeg(segment):
    HP = horizontalProjection(segment)
    tmp = []
    for i in range(len(HP)):
        if HP[i]:
            HP[i] = 1
        if HP[i] == 1:
            tmp.append(i)
    flag = False
    for i in range(len(tmp) - 1):
        if tmp[i + 1] - tmp[i] > 1:
            flag = True
            break
    if (np.sum(segment)//255) <= 4 and not flag:
        return True
    return False

def CharSegmentation(word,BLI):
    chars = []
    _, word = cv2.threshold(word, 127, 255, cv2.THRESH_BINARY_INV)
    VP = verticalProjection(word)
    wordC = np.copy(word)
    for i in range(len(VP)):
        if VP[i] < 2:
            VP[i] = 0
    if BLI < wordC.shape[0]:
        wordC[BLI, VP == 0] = 0
    VPC = verticalProjection(wordC)
    filterIdx = np.where(VPC == 0)[0]
    tmp = np.copy(filterIdx)
    tmp = np.diff(tmp)
    tmp = np.insert(tmp, 0, 0)
    cuts = filterIdx[tmp > 1]
    prev = 0
    for cut in cuts:
        if not isOverSeg(word[:, prev:cut]):
            chars.append(word[:, prev:cut])
        prev = cut 
    return chars

def run(input_image):
    lines = LineSegmentation(input_image)
    allChars = []
    for _, line in enumerate(lines, 1):
        words = WordSegmentation(line)
        BLI = BaselineDetection(line)
        for _, word in enumerate(words, 1):  
            chars = CharSegmentation(word,BLI)
            # for cntChar, char in enumerate(chars, 1):
            #     cv2.imwrite("./out/line%i - word%i - char%i.png"%(cntLine, cntWord, cntChar), char)
            allChars.append(chars)
    return allChars   

# if not os.path.isdir("out"):
#     os.mkdir("out")
# sample = cv2.imread("sample.png")
# sample = ToGray(sample)
# run(sample)
# lines = LineSegmentation(sample)
# for line in lines:
#     WordSegmentation(line)
# BLI = BaselineDetection(lines[0])
# MTI = FindingMaximumTransitions(lines[0], BLI)
# WordSegmentation(lines[0])
# print("BLI: ", BLI)
# print("MTI: ", MTI)