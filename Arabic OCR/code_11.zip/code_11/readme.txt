libraries needed:
	- numpy 
	- scipy 
	- imutils 
	- skimage
	- opencv

How to run:
	python main.py [path of input images]